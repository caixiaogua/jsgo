// gin.ctx

"use strict";

function main(){
	// return 666;
	var dbstr="testdb:#molJOCcqqJoYrmH6@tcp(192.168.1.205:3307)/testdb";
	var sqlstr="select * from json where id>1";
	var res=api.query(sqlstr, dbstr);
	return res;
}