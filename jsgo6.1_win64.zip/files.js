
function main(){
	//通过return返回一个函数
	return (v)=>{
		let res=api.goRun(`
			func(p string)interface{} {
			    files, err := ioutil.ReadDir(p)
			    if err != nil {
			        return err.Error();
			    }
			    return files;
			}
		`)(v);
		if(res.map)return res.map(x=>x.Name());
		else return res;
	}
}