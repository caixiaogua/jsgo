
function main(){
	if(!api.db.count)api.db.count=0;
	api.db.count++;
	return "首页-"+api.db.count;
}