//"jsgo buildx app.js"命令可将程序编译为app.sox文件，程序执行会优先选择sox文件
//"jsgo -port 888"命令可指定服务运行端口
//import后面加括号，表示在主线程中执行（更快），不加括号则在新线程中执行（适合耗时任务）

function main(ctx){
	let path=ctx.Request.URL.Path;
	if(path=="/"){
		//可自定义引用路由文件
		return api.import("main.js")();
	}else{
		//或者自动引用routes目录下的文件
		return api.import("routes"+path+".js")();
	}
}