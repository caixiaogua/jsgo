// gin.ctx

function main(){
	ctx.Header("Content-Type", "text/html; charset=utf-8");
	return "首页";
}