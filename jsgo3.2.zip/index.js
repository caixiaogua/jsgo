// gin.ctx

function main(){
	if(!api.db.count)api.db.count=0;
	api.db.count++;
	ctx.Header("Content-Type", "text/html; charset=utf-8");
	return "首页-"+api.db.count;
}