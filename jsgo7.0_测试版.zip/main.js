
function main(){
	return "main.js";
}