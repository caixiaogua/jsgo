//"jsgo buildx app.js"命令可将程序编译为app.sox文件，程序执行会优先选择sox文件
//"jsgo -port 888"命令可指定服务运行端口

let routes=api.getList("routes").map(x=>x.Name());

//载入templates文件夹中的模板文件
api.gin.LoadHTMLGlob("templates/*");

function main(ctx){
	let path=ctx.Request.URL.Path;
	if(path=="/"){
		//可渲染模板
		ctx.HTML(200, "index.tmpl", {title:"jsgo_test",list:[1,2,3]});
		//或者自定义引用路由文件
		// return api.import("main.js")();
	}else if(routes.includes(path.slice(1)+".js")){
		//或者自动引用routes目录下的文件
		return api.import("routes"+path+".js")();
	}else{
		return null;
	}
}