
function main(ctx){
	let res=api.php.FileGetContents("app.js");
	return res;
}