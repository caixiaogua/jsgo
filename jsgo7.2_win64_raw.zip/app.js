//"jsgo -port 888"命令可指定服务运行端口

//获取routes文件夹中的路由文件列表
// let routes=api.getList("routes").map(x=>x.Name());

//可载入templates文件夹中的模板文件，可自定义变量标签
//api.gin.Delims("{{", "}}");
//api.gin.LoadHTMLGlob("templates/*");

function main(ctx){
	let path=ctx.Request.URL.Path;	//获取当前路由
	if(path=="/"){
		//若已载入模板，可渲染模板页，并直接返回到客户端
		//ctx.HTML(200, "index.tmpl", {title:"jsgo_test",list:[1,2,3]});
		return "index";
	}else if(path=="/phptest"){
		return api.import("phptest.js")(ctx);
	}else if(path=="/main"){
		//或者引用指定的路由文件
		return api.import("main.js")(ctx);
	// }else if(routes.includes(path.slice(1)+".js")){	//如果路由表包含当前路由
	// 	//或者自动匹配routes目录下的文件
	// 	return api.import("routes"+path+".js")();
	}else{	//未匹配的路由返回null
		return null;
	}
}