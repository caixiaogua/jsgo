
function main(){
	//通过return返回一个函数
	return (v)=>{
		return "item-"+v;
	}
}