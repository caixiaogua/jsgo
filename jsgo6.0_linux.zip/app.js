//根目录存在app.so或app.js时，服务会启动为单体架构模式，整个项目的入口为app.so或app.js
//需要切换为微服务模式，请删除app.so和app.js文件，重新启动服务
//"jsgo init"命令可生成routes.ini路由表文件，该文件仅对微服务模式有效，单体模式无视该文件
//"jsgo build app.js"命令可将app.js编译为app.so文件，程序执行会优先选择so文件
//"jsgo -port 888"命令可指定服务运行端口

function main(){
	let path=ctx.Request.URL.Path;
	if(path=="/"){
		return api.import("count.so")();
	}else if(path=="/item"){
		return api.import("item.js")(6);
	}else if(path=="/files"){
		return api.import("files.js")(".");
	}
	return "none";
}