// gin.ctx

function main(){
	var time=new Date().toLocaleString();
	var act=ctx.Query("do");
	var topic=ctx.Query("topic");
	var db=api;
	// db.httpGet(url)
	// db.getFile(path)
	// db.saveFile(path, string)
	// return(ctx.Query("name"))
	// return(ctx.PostForm("password"))
	// return "当前时间："+time+"...";
	// var res=db.httpGet("http://www.baidu.com/");
	// return db.saveFile("baidu.txt", res);
	// db.remove("cat2.jpg")
	// return JSON.stringify(db.stat("dazi/20200.json"),null,2);
	db.name="mark";
	db.age=23;
	db.arr=[1,2,"333"];
	db.obj={child:5,wife:"lucy"};
	if(!db.count)db.count=0;
	db.count++;
	var i=66;
	// db.int32=db.vm.ToValue("httpGet");
	// db.println(db)
	return JSON.stringify(db.obj);
	// var upfile=ctx.FormFile("upfile")[0];
	// ctx.SaveUploadedFile(upfile, upfile.Filename);
	ctx.Header("Content-Type", "text/html; charset=utf-8");
	// return upfile.Filename;
	// return JSON.stringify(ctx.Request.Cookies());
	return db.httpGet("http://www.baidu.com/");
	// return JSON.stringify(JSON.parse(getFile("2020.json")),null,2);
	if(act=="getbj")
		return '{"logs":'+db.getFile("dazi/2020.json")+'}'
	else
		return db.getFile("dazi/main.html")
}